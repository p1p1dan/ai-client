const { app, BrowserWindow } = require('electron');
const fs = require('node:fs');
const output = '/home/pi/code/ai-client-runtime/docs/plantree/plans/runtime-evolution/evidence/session-review-and-updates';
app.setPath('userData','/tmp/aiclient-review-probe/profile');
app.commandLine.appendSwitch('disable-gpu');
const sleep = ms => new Promise(resolve=>setTimeout(resolve,ms));
const checks=[];
let win;
async function js(code){return win.webContents.executeJavaScript(code,true)}
async function waitFor(code,name){for(let i=0;i<100;i++){if(await js(code)){checks.push(name);return}await sleep(200)}throw new Error(name+' timed out')}
async function click(selector){await sleep(400);const rect=await js(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e)throw Error('missing '+${JSON.stringify(selector)});const r=e.getBoundingClientRect();return {x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)}})()`);await win.webContents.debugger.sendCommand('Input.dispatchMouseEvent',{type:'mouseMoved',button:'none',...rect});await win.webContents.debugger.sendCommand('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...rect});await win.webContents.debugger.sendCommand('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...rect});await sleep(350)}
async function clickText(label){const selector=await js(`(()=>{const el=[...document.querySelectorAll('button')].find(e=>e.textContent.trim()===${JSON.stringify(label)});if(!el)throw Error('missing label '+${JSON.stringify(label)});el.setAttribute('data-probe-click','yes');return '[data-probe-click="yes"]'})()`);await click(selector);await js(`document.querySelector('[data-probe-click]')?.removeAttribute('data-probe-click')`)}
async function capture(name){fs.writeFileSync(output+'/'+name,(await win.webContents.capturePage()).toPNG())}
app.whenReady().then(async()=>{
 fs.mkdirSync(output,{recursive:true});
 win=new BrowserWindow({width:1340,height:850,show:true,webPreferences:{contextIsolation:true,nodeIntegration:false}});
 win.webContents.on('console-message',(_e,level,message)=>{if(level>=2)console.log('BROWSER:',message)});
 win.webContents.debugger.attach('1.3');await win.loadURL('http://127.0.0.1:5179'); win.show(); win.focus();
 await waitFor(`!!document.querySelector('#chat-input')`,'shell mounted');
 await click('button[title="审阅"]');
 await waitFor(`document.querySelector('section[aria-label="审阅"]')?.textContent.includes('+abc')`,'review displays the second change');
 await click('[data-slot="collapsible-trigger"]');
 await capture('review-light.png');
 await js(`document.documentElement.classList.add('dark')`); await sleep(100);await capture('review-dark.png');
 win.setSize(1000,850);await sleep(350);
 const bounds=await js(`(()=>{const r=document.querySelector('section[aria-label="审阅"]').getBoundingClientRect();return {right:r.right,width:r.width,innerWidth:innerWidth}})()`);
 if(bounds.right>bounds.innerWidth+1||bounds.width<319)throw Error('review bounds '+JSON.stringify(bounds));checks.push('1000px review fits without clipping');
 await capture('review-narrow.png');
 win.setSize(1340,850);await sleep(350);
 await js(`window.probe.editor.setState({tabs:[{path:'/repo/dirty.txt',name:'dirty.txt',content:'unsaved text',isDirty:true}],activeTabPath:'/repo/dirty.txt'})`);
 await waitFor(`!!document.querySelector('#dirty-editor')`,'editor mounted');
 await js(`document.querySelector('#dirty-editor').value='keep my unsaved edit'`);
 await click('button[title="审阅"]');
 await waitFor(`!!document.querySelector('section[aria-label="审阅"]')`,'review reopens beside chat');
 await click('button[aria-label="文件"]');
 await waitFor(`!document.querySelector('section[aria-label="审阅"]')`,'files switch closes review');
 const editor=await js(`({value:document.querySelector('#dirty-editor').value,mounts:window.editorMounts,unmounts:window.editorUnmounts||0})`);
 if(editor.value!=='keep my unsaved edit'||editor.mounts!==1||editor.unmounts!==0)throw Error('editor preservation '+JSON.stringify(editor));checks.push('editor state preserved while review shown');
 await click('button[title="审阅"]');
 await js(`window.probe.chat.setState({activeSessionId:'other'})`);
 await waitFor(`document.querySelector('section[aria-label="审阅"]')?.textContent.includes('当前对话尚无')`,'session switching clears previous change list');
 await js(`window.probe.chat.setState({activeSessionId:'s'})`);
 await waitFor(`document.querySelector('section[aria-label="审阅"]')?.textContent.includes('test.txt')`,'switching back restores change list');
 await js(`window.probe.editor.getState().switchWorktree('/different-workspace')`);
 await waitFor(`document.querySelector('section[aria-label="审阅"]')?.textContent.includes('test.txt')`,'switching editor workspace does not dismiss review');
 await js(`window.probe.editor.getState().switchWorktree('/repo')`);
 await waitFor(`document.querySelector('section[aria-label="审阅"]')?.textContent.includes('test.txt')`,'restoring editor workspace keeps review visible');
 await click('[role="status"] button');
 await waitFor(`!!document.querySelector('[role="dialog"]')`,'update dialog opens');
 await clickText('下载更新');
 await waitFor(`document.querySelector('[role="dialog"]')?.textContent.includes('重启')`,'downloaded state displayed');
 await capture('update-ready.png');
 await clickText('稍后');
 await waitFor(`!document.querySelector('[role="dialog"]')&&!document.querySelector('[data-slot="dialog-backdrop"]')`,'Later removes dialog and backdrop');
 await click('#chat-input');
 await js(`document.querySelector('#chat-input').value='chat remains usable'`);
 if(!await js(`document.activeElement.id==='chat-input'`))throw Error('chat input blocked');checks.push('chat remains focusable after Later');
 await click('[role="status"] button');
 await waitFor(`!!document.querySelector('[role="dialog"]')`,'persistent update entry reopens dialog');
 await win.webContents.debugger.sendCommand('Input.dispatchKeyEvent',{type:'keyDown',key:'Escape',code:'Escape',windowsVirtualKeyCode:27});await win.webContents.debugger.sendCommand('Input.dispatchKeyEvent',{type:'keyUp',key:'Escape',code:'Escape',windowsVirtualKeyCode:27});
 await waitFor(`!document.querySelector('[role="dialog"]')&&!document.querySelector('[data-slot="dialog-backdrop"]')`,'Escape removes dialog and backdrop');
 if(await js(`!!window.installRequested`))throw Error('install happened without a request');checks.push('no install without restart click');
 fs.writeFileSync(output+'/browser-checks.json',JSON.stringify({checks,scope:'Real WorkspaceShell, SessionBar, SessionReviewPanel, UpdateNotification and stores; unrelated hosts and Electron IPC mocked; Chromium mouse and Escape input events in Linux Electron.'},null,2));
 console.log(JSON.stringify({ok:true,checks},null,2));app.quit();
}).catch(async error=>{console.error(error);if(win){await capture('probe-failure.png').catch(()=>{});console.error(await js(`document.body.innerText`).catch(()=>''))}app.exit(1)});
