import React from 'react';
import {createRoot} from 'react-dom/client';
import { WorkspaceShell } from '@/components/workspace-shell/WorkspaceShell';
import { UpdateNotification } from '@/components/UpdateNotification';
import {useChatSessionsStore} from '@/stores/chatSessions';
import {useEditorStore} from '@/stores/editor';
import {useSettingsStore} from '@/stores/settings';
import {useShellLayoutStore} from '@/stores/shellLayout';
import {useFileOpenIntentStore} from '@/stores/fileOpenIntent';
import '/home/pi/code/ai-client-runtime/src/renderer/styles/globals.css';
import './probe.css';
await useSettingsStore.persist.rehydrate();
useSettingsStore.setState({language:'zh',showSessionReview:true});
useShellLayoutStore.setState({sidebarWidth:280,activeSurfaceId:'chat',expanded:false,editorRatio:0.35});
function message(id,review){return {id,role:'assistant',sessionId:'s',blocks:[{id:id+'c',type:'tool_call',toolCallId:id,toolName:'write',toolInput:{path:review.path}},{id:id+'r',type:'tool_result',toolCallId:id,toolOk:true,toolOutput:{details:{review}}}]}}
useChatSessionsStore.setState({activeSessionId:'s',sessions:[{id:'s',title:'文件修改审阅',workspaceId:'w',status:'idle'},{id:'other',title:'另一个对话',workspaceId:'w',status:'idle'}],projects:[],workspaces:[{id:'w',path:'/repo',name:'测试工作区'}],messages:{s:[message('one',{version:1,path:'/repo/test.txt',status:'added',patch:'@@ -0,0 +1,1 @@\n+pong'}),message('two',{version:1,path:'/repo/test.txt',status:'modified',patch:'@@ -1,1 +1,2 @@\n pong\n+abc'})],other:[]}});
useEditorStore.setState({currentWorktreePath:'/repo'});
window.probe={chat:useChatSessionsStore,editor:useEditorStore,intent:useFileOpenIntentStore,layout:useShellLayoutStore};
createRoot(document.getElementById('root')!).render(<><WorkspaceShell/><UpdateNotification/></>);
