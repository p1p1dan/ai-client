import { createServer } from '/home/pi/code/ai-client-runtime/node_modules/vite/dist/node/index.js';
import react from '/home/pi/code/ai-client-runtime/node_modules/@vitejs/plugin-react/dist/index.js';
import tailwind from '/home/pi/code/ai-client-runtime/node_modules/@tailwindcss/vite/dist/index.mjs';
const repo = '/home/pi/code/ai-client-runtime';
const noops = ['useSyncChatWorkspaceTree','useShellShortcuts','useEditorWorktreeSync','useCapacityReclaimNotice'];
const stubs = Object.fromEntries(noops.map((name) => [name, `export function ${name}() {}`]));
stubs.usePresentationSwitch = `export function usePresentationSwitch(){ return {presentationMode:'gui', openGui(){}, openTui(){}}; }`;
stubs.useWorkspaceSearch = `export function useWorkspaceSearch(){return {request:null,openSearch(){}}}`;
stubs.LeftDock = `import {createElement as h} from 'react'; export function LeftDock(){return h('aside',{style:{width:280,padding:16,flexShrink:0},className:'border-r bg-card'},'会话列表 · 测试工作区');}`;
stubs.ChatWorkspace = `import {createElement as h} from 'react'; export function ChatWorkspace(){return h('main',{className:'min-h-0 flex-1 p-6'},h('p',{},'已在工作区创建 test.txt，写入 pong。'),h('p',{className:'mt-4'},'已在文件末尾追加 abc。'),h('textarea',{id:'chat-input',className:'mt-8 w-full rounded-md border p-3',placeholder:'继续当前对话…'}));}`;
stubs.GlobalSearchDialog = `export function GlobalSearchDialog(){return null}`;
stubs.EditorColumn = `import {createElement as h,useEffect} from 'react'; export function EditorColumn(){useEffect(()=>{window.editorMounts=(window.editorMounts||0)+1;return()=>{window.editorUnmounts=(window.editorUnmounts||0)+1}},[]);return h('textarea',{id:'dirty-editor',defaultValue:'unsaved text',className:'h-full w-full p-3'});}`;
const server = await createServer({
  configFile:false,logLevel:'error',root:'/tmp/aiclient-review-probe',server:{watch:{ignored:['**/profile/**','**/node_modules/**']},host:'127.0.0.1',port:5179,strictPort:true,fs:{allow:['/tmp/aiclient-review-probe',repo,'/home/pi/code/ai-client']}},
  resolve:{alias:{'@':repo+'/src/renderer','@shared':repo+'/src/shared'},dedupe:['react','react-dom']},
  plugins:[{name:'probe-stubs',enforce:'pre',resolveId(id){const name=id.split('/').at(-1)?.replace(/\.tsx?$/,'');if(stubs[name])return '\0probe:'+name;},load(id){if(id.startsWith('\0probe:'))return stubs[id.slice(7)];}},react(),tailwind()],
  optimizeDeps:{include:['react','react-dom/client']}
});
await server.listen();
console.log('PROBE_READY');
